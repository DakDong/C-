﻿namespace 仿XP系统的任务栏菜单
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_All = new System.Windows.Forms.Panel();
            this.panel_Gut_3 = new System.Windows.Forms.Panel();
            this.label_7 = new System.Windows.Forms.Label();
            this.label_6 = new System.Windows.Forms.Label();
            this.panel_Title3 = new System.Windows.Forms.Panel();
            this.pictureBox_3 = new System.Windows.Forms.PictureBox();
            this.panel_Border_2 = new System.Windows.Forms.Panel();
            this.panel_Gut_2 = new System.Windows.Forms.Panel();
            this.label_5 = new System.Windows.Forms.Label();
            this.label_4 = new System.Windows.Forms.Label();
            this.label_3 = new System.Windows.Forms.Label();
            this.panel_Title_2 = new System.Windows.Forms.Panel();
            this.pictureBox_2 = new System.Windows.Forms.PictureBox();
            this.panel_Border_1 = new System.Windows.Forms.Panel();
            this.panel_Gut_1 = new System.Windows.Forms.Panel();
            this.label_2 = new System.Windows.Forms.Label();
            this.label_1 = new System.Windows.Forms.Label();
            this.panel_Title_1 = new System.Windows.Forms.Panel();
            this.pictureBox_1 = new System.Windows.Forms.PictureBox();
            this.panel_All.SuspendLayout();
            this.panel_Gut_3.SuspendLayout();
            this.panel_Title3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_3)).BeginInit();
            this.panel_Gut_2.SuspendLayout();
            this.panel_Title_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_2)).BeginInit();
            this.panel_Gut_1.SuspendLayout();
            this.panel_Title_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::仿XP系统的任务栏菜单.Properties.Resources._1;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(208, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(352, 347);
            this.panel1.TabIndex = 1;
            // 
            // panel_All
            // 
            this.panel_All.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_All.BackgroundImage")));
            this.panel_All.Controls.Add(this.panel_Gut_3);
            this.panel_All.Controls.Add(this.panel_Title3);
            this.panel_All.Controls.Add(this.panel_Border_2);
            this.panel_All.Controls.Add(this.panel_Gut_2);
            this.panel_All.Controls.Add(this.panel_Title_2);
            this.panel_All.Controls.Add(this.panel_Border_1);
            this.panel_All.Controls.Add(this.panel_Gut_1);
            this.panel_All.Controls.Add(this.panel_Title_1);
            this.panel_All.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_All.Location = new System.Drawing.Point(0, 0);
            this.panel_All.Name = "panel_All";
            this.panel_All.Size = new System.Drawing.Size(208, 347);
            this.panel_All.TabIndex = 0;
            // 
            // panel_Gut_3
            // 
            this.panel_Gut_3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Gut_3.BackgroundImage")));
            this.panel_Gut_3.Controls.Add(this.label_7);
            this.panel_Gut_3.Controls.Add(this.label_6);
            this.panel_Gut_3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Gut_3.Location = new System.Drawing.Point(0, 262);
            this.panel_Gut_3.Name = "panel_Gut_3";
            this.panel_Gut_3.Size = new System.Drawing.Size(208, 81);
            this.panel_Gut_3.TabIndex = 7;
            this.panel_Gut_3.Tag = "0";
            // 
            // label_7
            // 
            this.label_7.AutoSize = true;
            this.label_7.BackColor = System.Drawing.Color.Transparent;
            this.label_7.Location = new System.Drawing.Point(43, 48);
            this.label_7.Name = "label_7";
            this.label_7.Size = new System.Drawing.Size(53, 12);
            this.label_7.TabIndex = 1;
            this.label_7.Text = "我的文档";
            this.label_7.MouseLeave += new System.EventHandler(this.label_1_MouseLeave);
            this.label_7.MouseEnter += new System.EventHandler(this.label_1_MouseEnter);
            // 
            // label_6
            // 
            this.label_6.AutoSize = true;
            this.label_6.BackColor = System.Drawing.Color.Transparent;
            this.label_6.Location = new System.Drawing.Point(43, 20);
            this.label_6.Name = "label_6";
            this.label_6.Size = new System.Drawing.Size(53, 12);
            this.label_6.TabIndex = 0;
            this.label_6.Text = "我的电脑";
            this.label_6.MouseLeave += new System.EventHandler(this.label_1_MouseLeave);
            this.label_6.MouseEnter += new System.EventHandler(this.label_1_MouseEnter);
            // 
            // panel_Title3
            // 
            this.panel_Title3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Title3.BackgroundImage")));
            this.panel_Title3.Controls.Add(this.pictureBox_3);
            this.panel_Title3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Title3.Location = new System.Drawing.Point(0, 237);
            this.panel_Title3.Name = "panel_Title3";
            this.panel_Title3.Size = new System.Drawing.Size(208, 25);
            this.panel_Title3.TabIndex = 6;
            // 
            // pictureBox_3
            // 
            this.pictureBox_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_3.Location = new System.Drawing.Point(171, 3);
            this.pictureBox_3.Name = "pictureBox_3";
            this.pictureBox_3.Size = new System.Drawing.Size(20, 20);
            this.pictureBox_3.TabIndex = 0;
            this.pictureBox_3.TabStop = false;
            this.pictureBox_3.Tag = "3";
            this.pictureBox_3.Click += new System.EventHandler(this.pictureBox_1_Click);
            // 
            // panel_Border_2
            // 
            this.panel_Border_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Border_2.BackgroundImage")));
            this.panel_Border_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Border_2.Location = new System.Drawing.Point(0, 227);
            this.panel_Border_2.Name = "panel_Border_2";
            this.panel_Border_2.Size = new System.Drawing.Size(208, 10);
            this.panel_Border_2.TabIndex = 5;
            // 
            // panel_Gut_2
            // 
            this.panel_Gut_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Gut_2.BackgroundImage")));
            this.panel_Gut_2.Controls.Add(this.label_5);
            this.panel_Gut_2.Controls.Add(this.label_4);
            this.panel_Gut_2.Controls.Add(this.label_3);
            this.panel_Gut_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Gut_2.Location = new System.Drawing.Point(0, 146);
            this.panel_Gut_2.Name = "panel_Gut_2";
            this.panel_Gut_2.Size = new System.Drawing.Size(208, 81);
            this.panel_Gut_2.TabIndex = 4;
            this.panel_Gut_2.Tag = "0";
            // 
            // label_5
            // 
            this.label_5.AutoSize = true;
            this.label_5.BackColor = System.Drawing.Color.Transparent;
            this.label_5.Location = new System.Drawing.Point(43, 59);
            this.label_5.Name = "label_5";
            this.label_5.Size = new System.Drawing.Size(53, 12);
            this.label_5.TabIndex = 2;
            this.label_5.Text = "Internet";
            this.label_5.MouseLeave += new System.EventHandler(this.label_1_MouseLeave);
            this.label_5.MouseEnter += new System.EventHandler(this.label_1_MouseEnter);
            // 
            // label_4
            // 
            this.label_4.AutoSize = true;
            this.label_4.BackColor = System.Drawing.Color.Transparent;
            this.label_4.Location = new System.Drawing.Point(43, 37);
            this.label_4.Name = "label_4";
            this.label_4.Size = new System.Drawing.Size(41, 12);
            this.label_4.TabIndex = 1;
            this.label_4.Text = "计算器";
            this.label_4.MouseLeave += new System.EventHandler(this.label_1_MouseLeave);
            this.label_4.MouseEnter += new System.EventHandler(this.label_1_MouseEnter);
            // 
            // label_3
            // 
            this.label_3.AutoSize = true;
            this.label_3.BackColor = System.Drawing.Color.Transparent;
            this.label_3.Location = new System.Drawing.Point(43, 15);
            this.label_3.Name = "label_3";
            this.label_3.Size = new System.Drawing.Size(41, 12);
            this.label_3.TabIndex = 0;
            this.label_3.Text = "记事本";
            this.label_3.MouseLeave += new System.EventHandler(this.label_1_MouseLeave);
            this.label_3.MouseEnter += new System.EventHandler(this.label_1_MouseEnter);
            // 
            // panel_Title_2
            // 
            this.panel_Title_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Title_2.BackgroundImage")));
            this.panel_Title_2.Controls.Add(this.pictureBox_2);
            this.panel_Title_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Title_2.Location = new System.Drawing.Point(0, 121);
            this.panel_Title_2.Name = "panel_Title_2";
            this.panel_Title_2.Size = new System.Drawing.Size(208, 25);
            this.panel_Title_2.TabIndex = 3;
            // 
            // pictureBox_2
            // 
            this.pictureBox_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_2.Location = new System.Drawing.Point(171, 3);
            this.pictureBox_2.Name = "pictureBox_2";
            this.pictureBox_2.Size = new System.Drawing.Size(20, 20);
            this.pictureBox_2.TabIndex = 0;
            this.pictureBox_2.TabStop = false;
            this.pictureBox_2.Tag = "2";
            this.pictureBox_2.Click += new System.EventHandler(this.pictureBox_1_Click);
            // 
            // panel_Border_1
            // 
            this.panel_Border_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Border_1.BackgroundImage")));
            this.panel_Border_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Border_1.Location = new System.Drawing.Point(0, 111);
            this.panel_Border_1.Name = "panel_Border_1";
            this.panel_Border_1.Size = new System.Drawing.Size(208, 10);
            this.panel_Border_1.TabIndex = 2;
            // 
            // panel_Gut_1
            // 
            this.panel_Gut_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Gut_1.BackgroundImage")));
            this.panel_Gut_1.Controls.Add(this.label_2);
            this.panel_Gut_1.Controls.Add(this.label_1);
            this.panel_Gut_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Gut_1.Location = new System.Drawing.Point(0, 30);
            this.panel_Gut_1.Name = "panel_Gut_1";
            this.panel_Gut_1.Size = new System.Drawing.Size(208, 81);
            this.panel_Gut_1.TabIndex = 1;
            this.panel_Gut_1.Tag = "0";
            // 
            // label_2
            // 
            this.label_2.AutoSize = true;
            this.label_2.BackColor = System.Drawing.Color.Transparent;
            this.label_2.Location = new System.Drawing.Point(43, 48);
            this.label_2.Name = "label_2";
            this.label_2.Size = new System.Drawing.Size(77, 12);
            this.label_2.TabIndex = 1;
            this.label_2.Text = "客户信息录入";
            this.label_2.MouseLeave += new System.EventHandler(this.label_1_MouseLeave);
            this.label_2.MouseEnter += new System.EventHandler(this.label_1_MouseEnter);
            // 
            // label_1
            // 
            this.label_1.AutoSize = true;
            this.label_1.BackColor = System.Drawing.Color.Transparent;
            this.label_1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_1.Location = new System.Drawing.Point(43, 20);
            this.label_1.Name = "label_1";
            this.label_1.Size = new System.Drawing.Size(77, 12);
            this.label_1.TabIndex = 0;
            this.label_1.Text = "产品信息录入";
            this.label_1.MouseLeave += new System.EventHandler(this.label_1_MouseLeave);
            this.label_1.MouseEnter += new System.EventHandler(this.label_1_MouseEnter);
            // 
            // panel_Title_1
            // 
            this.panel_Title_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Title_1.BackgroundImage")));
            this.panel_Title_1.Controls.Add(this.pictureBox_1);
            this.panel_Title_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Title_1.Location = new System.Drawing.Point(0, 0);
            this.panel_Title_1.Name = "panel_Title_1";
            this.panel_Title_1.Size = new System.Drawing.Size(208, 30);
            this.panel_Title_1.TabIndex = 0;
            // 
            // pictureBox_1
            // 
            this.pictureBox_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_1.Location = new System.Drawing.Point(171, 8);
            this.pictureBox_1.Name = "pictureBox_1";
            this.pictureBox_1.Size = new System.Drawing.Size(20, 20);
            this.pictureBox_1.TabIndex = 0;
            this.pictureBox_1.TabStop = false;
            this.pictureBox_1.Tag = "1";
            this.pictureBox_1.Click += new System.EventHandler(this.pictureBox_1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 347);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_All);
            this.Name = "Form1";
            this.Text = "仿XP系统的任务栏菜单";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_All.ResumeLayout(false);
            this.panel_Gut_3.ResumeLayout(false);
            this.panel_Gut_3.PerformLayout();
            this.panel_Title3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_3)).EndInit();
            this.panel_Gut_2.ResumeLayout(false);
            this.panel_Gut_2.PerformLayout();
            this.panel_Title_2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_2)).EndInit();
            this.panel_Gut_1.ResumeLayout(false);
            this.panel_Gut_1.PerformLayout();
            this.panel_Title_1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_All;
        private System.Windows.Forms.Panel panel_Title_1;
        private System.Windows.Forms.Panel panel_Gut_2;
        private System.Windows.Forms.Panel panel_Title_2;
        private System.Windows.Forms.Panel panel_Border_1;
        private System.Windows.Forms.Panel panel_Gut_1;
        private System.Windows.Forms.Panel panel_Border_2;
        private System.Windows.Forms.Panel panel_Title3;
        private System.Windows.Forms.Panel panel_Gut_3;
        private System.Windows.Forms.PictureBox pictureBox_1;
        private System.Windows.Forms.PictureBox pictureBox_2;
        private System.Windows.Forms.PictureBox pictureBox_3;
        private System.Windows.Forms.Label label_2;
        private System.Windows.Forms.Label label_1;
        private System.Windows.Forms.Label label_5;
        private System.Windows.Forms.Label label_4;
        private System.Windows.Forms.Label label_3;
        private System.Windows.Forms.Label label_7;
        private System.Windows.Forms.Label label_6;
        private System.Windows.Forms.Panel panel1;
    }
}

