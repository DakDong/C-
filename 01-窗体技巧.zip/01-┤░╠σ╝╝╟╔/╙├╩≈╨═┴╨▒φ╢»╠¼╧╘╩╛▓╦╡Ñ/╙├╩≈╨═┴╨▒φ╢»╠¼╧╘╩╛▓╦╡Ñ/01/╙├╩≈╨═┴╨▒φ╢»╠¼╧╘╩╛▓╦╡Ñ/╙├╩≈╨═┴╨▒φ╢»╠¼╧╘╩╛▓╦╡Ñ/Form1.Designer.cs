﻿namespace 用树型列表动态显示菜单
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ToolStrip_1_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_2_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_5 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_6 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_3_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_7 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_18 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_19 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_8 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_4_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_9 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_10 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_11 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_13 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_14 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_5_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_15 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_16 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_6_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_17 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_7_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_21 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_22 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_23 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_24 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_8_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_25 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_26 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_27 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_28 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_29 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_9_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip_30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.panel_Tree = new System.Windows.Forms.Panel();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel_Tree.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_1_0,
            this.ToolStrip_2_0,
            this.ToolStrip_3_0,
            this.ToolStrip_4_0,
            this.ToolStrip_5_0,
            this.ToolStrip_6_0,
            this.ToolStrip_7_0,
            this.ToolStrip_8_0,
            this.ToolStrip_9_0});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(641, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ToolStrip_1_0
            // 
            this.ToolStrip_1_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_1,
            this.ToolStrip_2,
            this.ToolStrip_3});
            this.ToolStrip_1_0.Name = "ToolStrip_1_0";
            this.ToolStrip_1_0.Size = new System.Drawing.Size(89, 20);
            this.ToolStrip_1_0.Tag = "0";
            this.ToolStrip_1_0.Text = "用户信息管理";
            // 
            // ToolStrip_1
            // 
            this.ToolStrip_1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStrip_1.Name = "ToolStrip_1";
            this.ToolStrip_1.Size = new System.Drawing.Size(166, 22);
            this.ToolStrip_1.Tag = "1";
            this.ToolStrip_1.Text = "求租人员信息设置";
            this.ToolStrip_1.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_2
            // 
            this.ToolStrip_2.Name = "ToolStrip_2";
            this.ToolStrip_2.Size = new System.Drawing.Size(166, 22);
            this.ToolStrip_2.Tag = "2";
            this.ToolStrip_2.Text = "出租人员信息设置";
            this.ToolStrip_2.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_3
            // 
            this.ToolStrip_3.Name = "ToolStrip_3";
            this.ToolStrip_3.Size = new System.Drawing.Size(166, 22);
            this.ToolStrip_3.Tag = "3";
            this.ToolStrip_3.Text = "人员信息控制";
            this.ToolStrip_3.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_2_0
            // 
            this.ToolStrip_2_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_4,
            this.toolStripMenuItem2,
            this.toolStripMenuItem1,
            this.ToolStrip_5,
            this.ToolStrip_6});
            this.ToolStrip_2_0.Enabled = false;
            this.ToolStrip_2_0.Name = "ToolStrip_2_0";
            this.ToolStrip_2_0.Size = new System.Drawing.Size(65, 20);
            this.ToolStrip_2_0.Tag = "0";
            this.ToolStrip_2_0.Text = "求租管理";
            // 
            // ToolStrip_4
            // 
            this.ToolStrip_4.Name = "ToolStrip_4";
            this.ToolStrip_4.Size = new System.Drawing.Size(142, 22);
            this.ToolStrip_4.Tag = "4";
            this.ToolStrip_4.Text = "房源查询设置";
            this.ToolStrip_4.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(142, 22);
            this.toolStripMenuItem2.Tag = "5";
            this.toolStripMenuItem2.Text = "房源状态浏览";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
            this.toolStripMenuItem1.Tag = "4";
            this.toolStripMenuItem1.Text = "房源查询设置";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_5
            // 
            this.ToolStrip_5.Name = "ToolStrip_5";
            this.ToolStrip_5.Size = new System.Drawing.Size(142, 22);
            this.ToolStrip_5.Tag = "5";
            this.ToolStrip_5.Text = "房源状态浏览";
            this.ToolStrip_5.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_6
            // 
            this.ToolStrip_6.Name = "ToolStrip_6";
            this.ToolStrip_6.Size = new System.Drawing.Size(142, 22);
            this.ToolStrip_6.Tag = "6";
            this.ToolStrip_6.Text = "求租意向设置";
            this.ToolStrip_6.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_3_0
            // 
            this.ToolStrip_3_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_7,
            this.ToolStrip_8});
            this.ToolStrip_3_0.Name = "ToolStrip_3_0";
            this.ToolStrip_3_0.Size = new System.Drawing.Size(65, 20);
            this.ToolStrip_3_0.Tag = "0";
            this.ToolStrip_3_0.Text = "员工信息";
            // 
            // ToolStrip_7
            // 
            this.ToolStrip_7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_18,
            this.ToolStrip_19});
            this.ToolStrip_7.Name = "ToolStrip_7";
            this.ToolStrip_7.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_7.Tag = "0";
            this.ToolStrip_7.Text = "录入员工信息";
            this.ToolStrip_7.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_18
            // 
            this.ToolStrip_18.Name = "ToolStrip_18";
            this.ToolStrip_18.Size = new System.Drawing.Size(142, 22);
            this.ToolStrip_18.Tag = "18";
            this.ToolStrip_18.Text = "单个信息录入";
            this.ToolStrip_18.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_19
            // 
            this.ToolStrip_19.Enabled = false;
            this.ToolStrip_19.Name = "ToolStrip_19";
            this.ToolStrip_19.Size = new System.Drawing.Size(142, 22);
            this.ToolStrip_19.Tag = "19";
            this.ToolStrip_19.Text = "批量信息录入";
            this.ToolStrip_19.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_8
            // 
            this.ToolStrip_8.Name = "ToolStrip_8";
            this.ToolStrip_8.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_8.Tag = "8";
            this.ToolStrip_8.Text = "所有员工信息";
            this.ToolStrip_8.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_4_0
            // 
            this.ToolStrip_4_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_9,
            this.ToolStrip_10,
            this.ToolStrip_11,
            this.ToolStrip_12,
            this.toolStripMenuItem7,
            this.toolStripMenuItem6,
            this.toolStripMenuItem5,
            this.toolStripMenuItem4,
            this.toolStripMenuItem3,
            this.ToolStrip_13,
            this.ToolStrip_14});
            this.ToolStrip_4_0.Name = "ToolStrip_4_0";
            this.ToolStrip_4_0.Size = new System.Drawing.Size(65, 20);
            this.ToolStrip_4_0.Tag = "0";
            this.ToolStrip_4_0.Text = "出租管理";
            // 
            // ToolStrip_9
            // 
            this.ToolStrip_9.Name = "ToolStrip_9";
            this.ToolStrip_9.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_9.Tag = "9";
            this.ToolStrip_9.Text = "房型信息设置";
            this.ToolStrip_9.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_10
            // 
            this.ToolStrip_10.Enabled = false;
            this.ToolStrip_10.Name = "ToolStrip_10";
            this.ToolStrip_10.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_10.Tag = "10";
            this.ToolStrip_10.Text = "楼层设置";
            this.ToolStrip_10.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_11
            // 
            this.ToolStrip_11.Name = "ToolStrip_11";
            this.ToolStrip_11.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_11.Tag = "11";
            this.ToolStrip_11.Text = "幢/座设置";
            this.ToolStrip_11.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_12
            // 
            this.ToolStrip_12.Enabled = false;
            this.ToolStrip_12.Name = "ToolStrip_12";
            this.ToolStrip_12.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_12.Tag = "12";
            this.ToolStrip_12.Text = "装修程度设置";
            this.ToolStrip_12.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem7.Tag = "13";
            this.toolStripMenuItem7.Text = "朝向设置";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Enabled = false;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem6.Tag = "12";
            this.toolStripMenuItem6.Text = "装修程度设置";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem5.Tag = "11";
            this.toolStripMenuItem5.Text = "幢/座设置";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Enabled = false;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem4.Tag = "10";
            this.toolStripMenuItem4.Text = "楼层设置";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem3.Tag = "9";
            this.toolStripMenuItem3.Text = "房型信息设置";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_13
            // 
            this.ToolStrip_13.Name = "ToolStrip_13";
            this.ToolStrip_13.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_13.Tag = "13";
            this.ToolStrip_13.Text = "朝向设置";
            this.ToolStrip_13.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_14
            // 
            this.ToolStrip_14.Name = "ToolStrip_14";
            this.ToolStrip_14.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_14.Tag = "14";
            this.ToolStrip_14.Text = "用途设置";
            this.ToolStrip_14.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_5_0
            // 
            this.ToolStrip_5_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_15,
            this.ToolStrip_16});
            this.ToolStrip_5_0.Name = "ToolStrip_5_0";
            this.ToolStrip_5_0.Size = new System.Drawing.Size(65, 20);
            this.ToolStrip_5_0.Tag = "0";
            this.ToolStrip_5_0.Text = "交费管理";
            // 
            // ToolStrip_15
            // 
            this.ToolStrip_15.Name = "ToolStrip_15";
            this.ToolStrip_15.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_15.Tag = "15";
            this.ToolStrip_15.Text = "收费设置";
            this.ToolStrip_15.Visible = false;
            this.ToolStrip_15.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_16
            // 
            this.ToolStrip_16.Name = "ToolStrip_16";
            this.ToolStrip_16.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_16.Tag = "16";
            this.ToolStrip_16.Text = "收费记录";
            this.ToolStrip_16.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_6_0
            // 
            this.ToolStrip_6_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_17});
            this.ToolStrip_6_0.Name = "ToolStrip_6_0";
            this.ToolStrip_6_0.Size = new System.Drawing.Size(65, 20);
            this.ToolStrip_6_0.Tag = "0";
            this.ToolStrip_6_0.Text = "业务统计";
            // 
            // ToolStrip_17
            // 
            this.ToolStrip_17.Name = "ToolStrip_17";
            this.ToolStrip_17.Size = new System.Drawing.Size(154, 22);
            this.ToolStrip_17.Tag = "17";
            this.ToolStrip_17.Text = "成交业务量统计";
            this.ToolStrip_17.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_7_0
            // 
            this.ToolStrip_7_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_21,
            this.ToolStrip_22,
            this.ToolStrip_23,
            this.ToolStrip_24});
            this.ToolStrip_7_0.Name = "ToolStrip_7_0";
            this.ToolStrip_7_0.Size = new System.Drawing.Size(65, 20);
            this.ToolStrip_7_0.Tag = "0";
            this.ToolStrip_7_0.Text = "常用工具";
            // 
            // ToolStrip_21
            // 
            this.ToolStrip_21.Name = "ToolStrip_21";
            this.ToolStrip_21.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_21.Tag = "21";
            this.ToolStrip_21.Text = "记事本";
            this.ToolStrip_21.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_22
            // 
            this.ToolStrip_22.Name = "ToolStrip_22";
            this.ToolStrip_22.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_22.Tag = "22";
            this.ToolStrip_22.Text = "记算器";
            this.ToolStrip_22.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_23
            // 
            this.ToolStrip_23.Name = "ToolStrip_23";
            this.ToolStrip_23.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_23.Tag = "23";
            this.ToolStrip_23.Text = "WORD";
            this.ToolStrip_23.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_24
            // 
            this.ToolStrip_24.Name = "ToolStrip_24";
            this.ToolStrip_24.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_24.Tag = "24";
            this.ToolStrip_24.Text = "EXCEL";
            this.ToolStrip_24.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_8_0
            // 
            this.ToolStrip_8_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_25,
            this.ToolStrip_26,
            this.ToolStrip_27,
            this.ToolStrip_28,
            this.ToolStrip_29});
            this.ToolStrip_8_0.Name = "ToolStrip_8_0";
            this.ToolStrip_8_0.Size = new System.Drawing.Size(65, 20);
            this.ToolStrip_8_0.Tag = "0";
            this.ToolStrip_8_0.Text = "系统管理";
            // 
            // ToolStrip_25
            // 
            this.ToolStrip_25.Name = "ToolStrip_25";
            this.ToolStrip_25.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_25.Tag = "25";
            this.ToolStrip_25.Text = "口令设置";
            this.ToolStrip_25.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_26
            // 
            this.ToolStrip_26.Name = "ToolStrip_26";
            this.ToolStrip_26.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_26.Tag = "26";
            this.ToolStrip_26.Text = "退出系统";
            this.ToolStrip_26.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_27
            // 
            this.ToolStrip_27.Name = "ToolStrip_27";
            this.ToolStrip_27.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_27.Tag = "27";
            this.ToolStrip_27.Text = "数据库备份";
            this.ToolStrip_27.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_28
            // 
            this.ToolStrip_28.Name = "ToolStrip_28";
            this.ToolStrip_28.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_28.Tag = "28";
            this.ToolStrip_28.Text = "数据库恢复";
            this.ToolStrip_28.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_29
            // 
            this.ToolStrip_29.Name = "ToolStrip_29";
            this.ToolStrip_29.Size = new System.Drawing.Size(152, 22);
            this.ToolStrip_29.Tag = "29";
            this.ToolStrip_29.Text = "清理无效信息";
            this.ToolStrip_29.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // ToolStrip_9_0
            // 
            this.ToolStrip_9_0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStrip_30});
            this.ToolStrip_9_0.Name = "ToolStrip_9_0";
            this.ToolStrip_9_0.Size = new System.Drawing.Size(41, 20);
            this.ToolStrip_9_0.Tag = "0";
            this.ToolStrip_9_0.Text = "帮助";
            // 
            // ToolStrip_30
            // 
            this.ToolStrip_30.Name = "ToolStrip_30";
            this.ToolStrip_30.Size = new System.Drawing.Size(118, 22);
            this.ToolStrip_30.Tag = "30";
            this.ToolStrip_30.Text = "帮助文件";
            this.ToolStrip_30.Click += new System.EventHandler(this.ToolStrip_1_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(641, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(97, 22);
            this.toolStripButton1.Tag = "1";
            this.toolStripButton1.Text = "求租人员信息";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(121, 22);
            this.toolStripButton2.Tag = "2";
            this.toolStripButton2.Text = "出租人员信息设置";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(97, 22);
            this.toolStripButton3.Tag = "4";
            this.toolStripButton3.Text = "房源查询设置";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(73, 22);
            this.toolStripButton4.Tag = "16";
            this.toolStripButton4.Text = "收费记录";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(109, 22);
            this.toolStripButton5.Tag = "17";
            this.toolStripButton5.Text = "成交业务量统计";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // panel_Tree
            // 
            this.panel_Tree.Controls.Add(this.treeView1);
            this.panel_Tree.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Tree.Location = new System.Drawing.Point(0, 49);
            this.panel_Tree.Name = "panel_Tree";
            this.panel_Tree.Size = new System.Drawing.Size(192, 374);
            this.panel_Tree.TabIndex = 5;
            // 
            // treeView1
            // 
            this.treeView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(192, 374);
            this.treeView1.TabIndex = 8;
            this.treeView1.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseDoubleClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::用树型列表动态显示菜单.Properties.Resources._1;
            this.pictureBox1.Location = new System.Drawing.Point(192, 49);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(449, 374);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 423);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel_Tree);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "用树型列表动态显示菜单";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel_Tree.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_1_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_1;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_2;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_3;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_2_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_4;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_5;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_6;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_3_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_7;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_8;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_4_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_9;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_10;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_11;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_12;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_13;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_14;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_5_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_15;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_16;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_6_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_17;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_7_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_21;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_22;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_23;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_24;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_8_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_25;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_26;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_27;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_28;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_29;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_9_0;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_30;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Panel panel_Tree;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_18;
        private System.Windows.Forms.ToolStripMenuItem ToolStrip_19;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

